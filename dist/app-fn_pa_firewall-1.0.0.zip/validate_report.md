

# Validation Report for Palo Alto Firewall

| SDK Version       | Generation Time          | Command Line Arguments Provided |
| :---------------- | ------------------------ | ------------------------------- |
| 48.0.4034 | 2023/03/10 16:16:14 | `package`: fn_pa_firewall, `validate`: True |

## Results
| **Severity** | **Count** |
| :----------- | --------- |
| Critical Issues:    | <span style="color:red"> 3 </span> |
| Warnings:           | <span style="color:orange"> 1 </span>  |
| Validations Passed: | <span style="color:green"> 38  </span>   |


## App Details
| Attribute | Value |
| --------- | ----- |
| `display_name` | Palo Alto Firewall |
| `name` | fn_pa_firewall |
| `version` | 1.0.0 |
| `author` | CMC TS SOC |
| `author_email` | scenterportal@cmc.com.vn |
| `install_requires` | ['resilient-circuits>=47.1.0'] |
| `description` | SOAR Components to Integrate with the Palo Alto Firewall |
| `long_description` | This integration contains Functions to interact with address groups, addresses, Global Protect User within Palo Alto Firewall. |
| `url` | https://cmctssg.vn |
| `entry_points` | {'resilient.circuits.configsection': 'D:\\Code '<br>                                     'CMC\\fn_pa_firewall\\fn_pa_firewall\\util\\config.py',<br> 'resilient.circuits.customize': 'D:\\Code '<br>                                 'CMC\\fn_pa_firewall\\fn_pa_firewall\\util\\customize.py',<br> 'resilient.circuits.selftest': 'D:\\Code '<br>                                'CMC\\fn_pa_firewall\\fn_pa_firewall\\util\\selftest.py'} |
| `python_requires` | >=3.6 |
| `SOAR version` | 41.2.41 |
| `Proxy support` | Proxies supported if running on AppHost>=1.6 |

---


## `setup.py` file validation
| Severity | Name | Description | Solution |
| --- | --- | --- | --- |

<span style="color:green">Success</span>


---


## Package files validation

### LICENSE
<span style="color:red">CRITICAL</span>: `LICENSE` is the default license file

Provide a `LICENSE` file in your package directory. Suggested formats: MIT, Apache, and BSD


### `Dockerfile, template match`
<span style="color:orange">WARNING</span>: `Dockerfile` does not match the template file (99% match). Difference from template:

```diff
--- Dockerfile template
+++ Dockerfile
@@ -34 +34 @@
-#RUN pip install <package>
+RUN pip install defusedxml
```

Ensure that the `Dockerfile` was generated with the latest version of the resilient-sdk...


### `MANIFEST.in`
<span style="color:green">Pass</span>


### `apikey_permissions.txt`
<span style="color:green">Pass</span>


### `Dockerfile, base image`
<span style="color:green">Pass</span>


### `entrypoint.sh`
<span style="color:green">Pass</span>


### ``config.py``
<span style="color:green">Pass</span>


### ``customize.py``
<span style="color:green">Pass</span>


### `SOAR Scripts`
<span style="color:green">Pass</span>


### `README.md`
<span style="color:green">Pass</span>


### `app_logo.png`
<span style="color:green">Pass</span>


### `company_logo.png`
<span style="color:green">Pass</span>

 
---
 

## Payload samples validation

### `payload_samples\palo_alto_firewall_create_a_new_tag`
<span style="color:green">Pass</span>


### `payload_samples\palo_alto_firewall_create_an_ip_address_object`
<span style="color:green">Pass</span>


### `payload_samples\palo_alto_firewall_delete_an_ip_address_object`
<span style="color:green">Pass</span>


### `payload_samples\palo_alto_firewall_disconnect_a_globalprotect_user`
<span style="color:green">Pass</span>


### `payload_samples\palo_alto_firewall_view_all_globalprotect_users`
<span style="color:green">Pass</span>

 
---
 

## `resilient-circuits` selftest
<span style="color:red">CRITICAL</span>: selftest.py not implemented for fn_pa_firewall

selftest.py is a recommended check that should be implemented.


---
 

## tox tests
<span style="color:red">CRITICAL</span>: Something went wrong... Details:

	py36: skipped because could not find python interpreter with spec(s): py36
	py36: SKIP ? in 0.55 seconds
	py39: skipped because could not find python interpreter with spec(s): py39
	  py36: SKIP (0.55 seconds)
	  py39: SKIP (0.02 seconds)
	  evaluation failed :( (0.83 seconds)
	


Run with the `-v` flag to see more information



---
 

## Pylint Scan
<span style="color:teal">INFO</span>: Pylint scan passed with no errors

Run with `-v` to see the full pylint output



---
 

## Bandit Scan
<span style="color:teal">INFO</span>: Bandit scan passed with no issues

Run again with `-v` to see the full bandit output



---
 